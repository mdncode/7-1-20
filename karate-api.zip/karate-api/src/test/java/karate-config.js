function fn() {    
  var env = karate.env; // get system property 'karate.env'
  karate.log('karate.env system property was:', env);
  if (!env) {
    env = 'uat';
  }
  var config = {
    env: env
  }
  if(env == 'dev'){
    config.apigeeurl= "https://dev1-api.cvshealth.com/";
  }
  if (env == 'uat') {
    config.uatUrl = "https://www-uat4.cvs.com/";
    config.apigeeurl= "https://dev1-api.cvshealth.com/";
  } 
   if (env == 'reg') {
    // customize
  }
  
  karate.configure('ssl',true)
  return config;
}