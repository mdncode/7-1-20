package utils;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class GetUTCTime {

    private static final String DATE_FORMAT = "dd-M-yyyy hh:mm:ss a";
    // public static Date GetCurrentUTCTime() {
    //     //OffsetDateTime now = OffsetDateTime.now(ZoneOffset.UTC);
    //     Calendar cal = Calendar.getInstance();
    //     cal.add(Calendar.HOUR_OF_DAY, +1);
    //     Date abc =  cal.getTime();
    //   //  OffsetDateTime now = OffsetDateTime.abc(ZoneOffset.UTC);
         
    // }

    // public static OffsetDateTime GetUTCTimeByTimeZone() {
    //     LocalDateTime dateInString = OffsetDateTime.now(ZoneOffset.UTC).toLocalDateTime();
	// 	System.out.println(dateInString);
    //     LocalDateTime ldt = dateInString;
    //     ZoneId centralZoneId = ZoneId.of("CDT");
    //     // ZoneId centralZoneId = ZoneId.of("America/Chicago");
      
    //     ZonedDateTime chicagoTime = ldt.atZone(centralZoneId);
      
    //     ZoneId easternZoneId = ZoneId.of("America/New_York");
       
    //     ZonedDateTime nyDateTime = chicagoTime.withZoneSameInstant(easternZoneId);
    //     OffsetDateTime offsetdate = nyDateTime.toOffsetDateTime();
    //     // OffsetDateTime offsetdateplusthree =offsetdate.plusHours(3);
    //     OffsetDateTime offsetdateplusone =offsetdate.plusHours(1);
    //     // return offsetdateplusthree;
    //     return offsetdateplusone;
    // }
    public static OffsetDateTime GetUTCTimeByTimeZone() {
        LocalDateTime dateInString = OffsetDateTime.now(ZoneOffset.UTC).toLocalDateTime();
		System.out.println(dateInString);
        LocalDateTime ldt = dateInString;
        ZoneId centralZoneId = ZoneId.of("America/Chicago");
      
        ZonedDateTime chicagoTime = ldt.atZone(centralZoneId);
      
        ZoneId easternZoneId = ZoneId.of("America/New_York");
       
        ZonedDateTime nyDateTime = chicagoTime.withZoneSameInstant(easternZoneId);
        OffsetDateTime offsetdate = nyDateTime.toOffsetDateTime();
        OffsetDateTime offsetdateplusone =offsetdate.plusHours(1);
        return offsetdateplusone;
    }


}